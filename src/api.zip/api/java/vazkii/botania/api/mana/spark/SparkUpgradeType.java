package vazkii.botania.api.mana.spark;

public enum SparkUpgradeType {
    NONE,
    DISPERSIVE,
    DOMINANT,
    RECESSIVE,
    ISOLATED
}
