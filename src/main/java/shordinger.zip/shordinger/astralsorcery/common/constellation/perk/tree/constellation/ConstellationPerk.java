/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.common.constellation.perk.tree.constellation;

import shordinger.astralsorcery.common.constellation.IConstellation;
import shordinger.astralsorcery.common.constellation.perk.attribute.AttributeModifierPerk;
import shordinger.astralsorcery.common.constellation.perk.tree.PerkTreePoint;
import shordinger.astralsorcery.common.constellation.perk.tree.PerkTreePointConstellation;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: ConstellationPerk
 * Created by HellFirePvP
 * Date: 11.11.2018 / 10:00
 */
public abstract class ConstellationPerk extends AttributeModifierPerk {

    private IConstellation constellation;

    public ConstellationPerk(String name, IConstellation cst, int x, int y) {
        super(name, x, y);
        setCategory(CATEGORY_KEY);
        this.constellation = cst;
    }

    @Override
    protected PerkTreePoint<? extends ConstellationPerk> initPerkTreePoint() {
        return new PerkTreePointConstellation<>(
            this,
            getOffset(),
            this.constellation,
            PerkTreePointConstellation.MINOR_SPRITE_SIZE);
    }

    public IConstellation getConstellation() {
        return constellation;
    }

}
