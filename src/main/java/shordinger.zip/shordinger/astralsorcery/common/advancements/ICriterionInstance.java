package shordinger.astralsorcery.common.advancements;

import net.minecraft.util.ResourceLocation;

public interface ICriterionInstance
{
    ResourceLocation getId();
}
