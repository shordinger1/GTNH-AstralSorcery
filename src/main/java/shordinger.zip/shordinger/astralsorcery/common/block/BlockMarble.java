/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.common.block;

import com.google.common.collect.Maps;
import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.ForgeDirection;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.IBlockAccess;
import shordinger.astralsorcery.common.lib.BlocksAS;
import shordinger.astralsorcery.common.registry.RegistryItems;
import shordinger.astralsorcery.common.util.MiscUtils;
import shordinger.astralsorcery.migration.IStringSerializable;
import shordinger.astralsorcery.migration.WorldHelper;
import shordinger.astralsorcery.migration.block.AstralBlock;
import shordinger.astralsorcery.migration.block.BlockFaceShape;
import shordinger.astralsorcery.migration.block.BlockPos;
import shordinger.astralsorcery.migration.block.BlockStateContainer;
import shordinger.astralsorcery.migration.block.IBlockState;
import shordinger.astralsorcery.migration.NonNullList;

import java.util.LinkedList;
import java.util.List;

public class BlockMarble extends AstralBlock implements BlockCustomName, BlockVariants, BlockDynamicStateMapper.Festive {

    // private static final int RAND_MOSS_CHANCE = 10;

    public static PropertyEnum<MarbleBlockType> MARBLE_TYPE = PropertyEnum.create("marbletype", MarbleBlockType.class);

    public BlockMarble() {
        super(Material.ROCK, MapColor.GRAY);
        setHardness(1.0F);
        setHarvestLevel("pickaxe", 1);
        setResistance(3.0F);
        setSoundType(SoundType.STONE);
        // setTickRandomly(true);
        setCreativeTab(RegistryItems.creativeTabAstralSorcery);
        setDefaultState(
            this.blockState.getBaseState()
                .withProperty(MARBLE_TYPE, MarbleBlockType.RAW));
    }

    @Override
    public void getSubBlocks(CreativeTabs tab, NonNullList<ItemStack> list) {
        for (MarbleBlockType t : MarbleBlockType.values()) {
            if (!t.obtainableInCreative()) continue;
            list.add(new ItemStack(this, 1, t.getMeta()));
        }
    }

    /*
     * @Override
     * public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
     * if (!worldIn.isRemote && worldIn.isRaining() && rand.nextInt(RAND_MOSS_CHANCE) == 0) {
     * MarbleBlockType type = state.getValue(MARBLE_TYPE);
     * if (type.canTurnMossy() && worldIn.isRainingAt(pos)) {
     * worldIn.setBlockState(pos, state.withProperty(MARBLE_TYPE, type.getMossyEquivalent()), 3);
     * }
     * }
     * }
     */

    @Override
    public IBlockState getActualState(IBlockState state, IBlockAccess worldIn, BlockPos pos) {
        // return super.getActualState(state, worldIn, pos);
        if (state.getValue(MARBLE_TYPE)
            .isPillar()) {
            IBlockState st = worldIn.getBlockState(pos.up());
            boolean top = st.getBlock() instanceof BlockMarble && st.getValue(MARBLE_TYPE)
                .isPillar();
            st = worldIn.getBlockState(pos.down());
            boolean down = st.getBlock() instanceof BlockMarble && st.getValue(MARBLE_TYPE)
                .isPillar();
            if (top && down) {
                return state.withProperty(MARBLE_TYPE, MarbleBlockType.PILLAR);
            } else if (top) {
                return state.withProperty(MARBLE_TYPE, MarbleBlockType.PILLAR_BOTTOM);
            } else if (down) {
                return state.withProperty(MARBLE_TYPE, MarbleBlockType.PILLAR_TOP);
            } else {
                return state.withProperty(MARBLE_TYPE, MarbleBlockType.PILLAR);
            }
        }
        return super.getActualState(state, worldIn, pos);
    }

    @Override
    public BlockFaceShape getBlockFaceShape(IBlockAccess p_193383_1_, IBlockState p_193383_2_, BlockPos p_193383_3_,
                                            ForgeDirection p_193383_4_) {
        return p_193383_2_.getValue(MARBLE_TYPE)
            .isPillar() ? BlockFaceShape.UNDEFINED : BlockFaceShape.SOLID;
    }

    @Override
    public int damageDropped(IBlockState state) {
        return getMetaFromState(state);
    }

    @Override
    public int getLightOpacity(IBlockState state, IBlockAccess world, BlockPos pos) {
        MarbleBlockType marbleType = state.getValue(MARBLE_TYPE);
        if (marbleType == MarbleBlockType.PILLAR_TOP || marbleType == MarbleBlockType.PILLAR
            || marbleType == MarbleBlockType.PILLAR_BOTTOM) {
            return 0;
        }
        return super.getLightOpacity(state, world, pos);
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        MarbleBlockType marbleType = state.getValue(MARBLE_TYPE);
        return marbleType != MarbleBlockType.PILLAR && marbleType != MarbleBlockType.PILLAR_BOTTOM
            && marbleType != MarbleBlockType.PILLAR_TOP;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        MarbleBlockType marbleType = state.getValue(MARBLE_TYPE);
        return marbleType != MarbleBlockType.PILLAR && marbleType != MarbleBlockType.PILLAR_BOTTOM
            && marbleType != MarbleBlockType.PILLAR_TOP;
    }

    @Override
    public boolean isFullBlock(IBlockState state) {
        MarbleBlockType marbleType = state.getValue(MARBLE_TYPE);
        return marbleType != MarbleBlockType.PILLAR && marbleType != MarbleBlockType.PILLAR_BOTTOM
            && marbleType != MarbleBlockType.PILLAR_TOP;
    }

    @Override
    public boolean doesSideBlockRendering(IBlockState state, IBlockAccess world, BlockPos pos, ForgeDirection face) {
        MarbleBlockType marbleType = state.getValue(MARBLE_TYPE);
        IBlockState other = WorldHelper.getBlockState(world, pos.offset(face));
        if (MiscUtils.isFluidBlock(other)
            && (marbleType == MarbleBlockType.PILLAR || marbleType == MarbleBlockType.PILLAR_BOTTOM
            || marbleType == MarbleBlockType.PILLAR_TOP)) {
            return false;
        }
        if (marbleType == MarbleBlockType.PILLAR_TOP) {
            return face == ForgeDirection.UP;
        }
        if (marbleType == MarbleBlockType.PILLAR_BOTTOM) {
            return face == ForgeDirection.DOWN;
        }
        return state.isOpaqueCube();
    }

    @Override
    public boolean isTopSolid(IBlockState state) {
        return true;
    }

    @Override
    public String getIdentifierForMeta(int meta) {
        MarbleBlockType mt = getStateFromMeta(meta).getValue(MARBLE_TYPE);
        return mt.getName();
    }

    @Override
    public int getMetaFromState(IBlockState state) {
        MarbleBlockType type = state.getValue(MARBLE_TYPE);
        return type.getMeta();
    }

    @Override
    public IBlockState getStateFromMeta(int meta) {
        return meta < MarbleBlockType.values().length
            ? getDefaultState().withProperty(MARBLE_TYPE, MarbleBlockType.values()[meta])
            : getDefaultState();
    }

    @Override
    protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, MARBLE_TYPE);
    }

    @Override
    public List<IBlockState> getValidStates() {
        List<IBlockState> ret = new LinkedList<>();
        for (MarbleBlockType type : MarbleBlockType.values()) {
            ret.add(getDefaultState().withProperty(MARBLE_TYPE, type));
        }
        return ret;
    }

    @Override
    public String getStateName(IBlockState state) {
        return state.getValue(MARBLE_TYPE)
            .getName() + (handleRegisterStateMapper() ? "_festive" : "");
    }

    @Override
    public Map<IBlockState, ModelResourceLocation> getModelLocations(Block blockIn) {
        ResourceLocation rl = Block.REGISTRY.getNameForObject(blockIn);
        rl = new ResourceLocation(rl.getResourceDomain(), rl.getResourcePath() + "_festive");
        Map<IBlockState, ModelResourceLocation> out = Maps.newHashMap();
        for (IBlockState state : getValidStates()) {
            out.put(state, new ModelResourceLocation(rl, getPropertyString(state.getProperties())));
        }
        return out;
    }

    public static enum MarbleBlockType implements IStringSerializable {

        RAW(0),
        BRICKS(1),
        PILLAR(2),
        ARCH(3),
        CHISELED(4),
        ENGRAVED(5),
        RUNED(6),

        PILLAR_TOP(2),
        PILLAR_BOTTOM(2);

        // BRICKS_MOSSY,
        // PILLAR_MOSSY,
        // CRACK_MOSSY;

        private final int meta;

        private MarbleBlockType(int meta) {
            this.meta = meta;
        }

        public ItemStack asStack() {
            return new ItemStack(BlocksAS.blockMarble, 1, meta);
        }

        public IBlockState asBlock() {
            return BlocksAS.blockMarble.getStateFromMeta(meta);
        }

        public boolean isPillar() {
            return this == PILLAR_BOTTOM || this == PILLAR || this == PILLAR_TOP;
        }

        public boolean obtainableInCreative() {
            return this != PILLAR_TOP && this != PILLAR_BOTTOM;
        }

        public int getMeta() {
            return meta;
        }

        @Override
        public String getName() {
            return name().toLowerCase();
        }

        /*
         * public boolean canTurnMossy() {
         * return this == BRICKS || this == PILLAR || this == CRACKED;
         * }
         * public MarbleBlockType getMossyEquivalent() {
         * if(!canTurnMossy()) return null;
         * switch (this) {
         * case BRICKS:
         * return BRICKS_MOSSY;
         * case PILLAR:
         * return PILLAR_MOSSY;
         * case CRACKED:
         * return CRACK_MOSSY;
         * }
         * return null;
         * }
         */
    }

}
