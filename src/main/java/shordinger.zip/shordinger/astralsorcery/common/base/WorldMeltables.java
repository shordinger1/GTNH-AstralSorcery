/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.common.base;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.world.World;

import shordinger.astralsorcery.common.constellation.effect.GenListEntries;
import shordinger.astralsorcery.common.util.BlockStateCheck;
import shordinger.astralsorcery.common.util.ItemUtils;
import shordinger.astralsorcery.common.util.MiscUtils;
import shordinger.astralsorcery.migration.WorldHelper;
import shordinger.astralsorcery.migration.block.BlockPos;
import shordinger.astralsorcery.migration.ChunkPos;
import shordinger.astralsorcery.migration.block.IBlockState;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: WorldMeltables
 * Created by HellFirePvP
 * Date: 31.10.2016 / 22:49
 */
public enum WorldMeltables implements MeltInteraction {

    COBBLE(new BlockStateCheck.Block(Blocks.COBBLESTONE), Blocks.FLOWING_LAVA.getDefaultState(), 180),
    STONE(new BlockStateCheck.Block(Blocks.stone), Blocks.FLOWING_LAVA.getDefaultState(), 100),
    OBSIDIAN(new BlockStateCheck.Block(Blocks.obsidian), Blocks.FLOWING_LAVA.getDefaultState(), 75),
    NETHERRACK(new BlockStateCheck.Block(Blocks.NETHERRACK), Blocks.FLOWING_LAVA.getDefaultState(), 40),
    NETHERBRICK(new BlockStateCheck.Block(Blocks.NETHER_BRICK), Blocks.FLOWING_LAVA.getDefaultState(), 60),
    MAGMA(new BlockStateCheck.Block(Blocks.MAGMA), Blocks.FLOWING_LAVA.getDefaultState(), 1),
    ICE(new BlockStateCheck.Block(Blocks.ice), Blocks.FLOWING_WATER.getDefaultState(), 1),
    FROSTED_ICE(new BlockStateCheck.Block(Blocks.FROSTED_ICE), Blocks.FLOWING_WATER.getDefaultState(), 1),
    PACKED_ICE(new BlockStateCheck.Block(Blocks.PACKED_ICE), Blocks.FLOWING_WATER.getDefaultState(), 2);

    private final BlockStateCheck meltableCheck;
    private final IBlockState meltResult;
    private final int meltDuration;

    private WorldMeltables(BlockStateCheck meltableCheck, IBlockState meltResult, int meltDuration) {
        this.meltableCheck = meltableCheck;
        this.meltResult = meltResult;
        this.meltDuration = meltDuration;
    }

    @Override
    public boolean isMeltable(World world, BlockPos pos, IBlockState worldState) {
        return meltableCheck.isStateValid(worldState);
    }

    @Override
    @Nullable
    public IBlockState getMeltResultState() {
        return meltResult;
    }

    @Override
    @Nonnull
    public ItemStack getMeltResultStack() {
        return null;
    }

    @Override
    public int getMeltTickDuration() {
        return meltDuration;
    }

    @Nullable
    public static MeltInteraction getMeltable(World world, BlockPos pos) {
        IBlockState state = WorldHelper.getBlockState(world, pos);
        for (WorldMeltables melt : values()) {
            if (melt.isMeltable(world, pos, state)) return melt;
        }
        ItemStack stack = ItemUtils.createBlockStack(state);
        if (stack.stackSize!=0) {
            ItemStack out = FurnaceRecipes.smelting()
                .getSmeltingResult(stack);
            if (out.stackSize!=0) {
                return new FurnaceRecipeInteraction(state, out);
            }
        }
        return null;
    }

    public static class ActiveMeltableEntry extends GenListEntries.CounterListEntry {

        public ActiveMeltableEntry(BlockPos pos) {
            super(pos);
        }

        public boolean isValid(World world, boolean forceLoad) {
            if (!forceLoad && !MiscUtils.isChunkLoaded(world, new ChunkPos(pos()))) return true;
            return getMeltable(world) != null;
        }

        public MeltInteraction getMeltable(World world) {
            return WorldMeltables.getMeltable(world, pos());
        }

    }

    public static class FurnaceRecipeInteraction implements MeltInteraction {

        private final ItemStack out;
        private final BlockStateCheck.Meta matchInState;

        public FurnaceRecipeInteraction(IBlockState inState, ItemStack outStack) {
            this.matchInState = new BlockStateCheck.Meta(
                inState.getBlock(),
                inState.getBlock()
                    .getMetaFromState(inState));
            this.out = outStack;
        }

        @Override
        public boolean isMeltable(World world, BlockPos pos, IBlockState state) {
            return matchInState.isStateValid(state);
        }

        @Nullable
        @Override
        public IBlockState getMeltResultState() {
            return ItemUtils.createBlockState(out);
        }

        @Nonnull
        @Override
        public ItemStack getMeltResultStack() {
            return out.copy();
        }

    }

}
