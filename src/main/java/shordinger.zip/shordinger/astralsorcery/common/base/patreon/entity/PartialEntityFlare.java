/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.common.base.patreon.entity;

import java.awt.*;
import java.util.UUID;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import shordinger.astralsorcery.client.effect.EffectHandler;
import shordinger.astralsorcery.client.effect.EffectHelper;
import shordinger.astralsorcery.client.effect.EntityComplexFX;
import shordinger.astralsorcery.client.effect.fx.EntityFXFacingParticle;
import shordinger.astralsorcery.client.effect.fx.EntityFXFacingSprite;
import shordinger.astralsorcery.client.util.resource.RowSpriteSheetResource;
import shordinger.astralsorcery.client.util.resource.SpriteSheetResource;
import shordinger.astralsorcery.common.base.patreon.PatreonEffectHelper;
import shordinger.astralsorcery.common.base.patreon.flare.PatreonPartialEntity;
import shordinger.astralsorcery.common.data.config.Config;
import shordinger.astralsorcery.common.util.data.Vector3;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: PartialEntityFlare
 * Created by HellFirePvP
 * Date: 23.06.2018 / 14:19
 */
public class PartialEntityFlare extends PatreonPartialEntity {

    private final PatreonEffectHelper.FlareColor flareColor;

    public Object clientSprite = null;

    public PartialEntityFlare(PatreonEffectHelper.FlareColor flareColor, UUID ownerUUID) {
        super(ownerUUID);
        this.flareColor = flareColor;
    }

    @SideOnly(Side.CLIENT)
    protected void spawnEffects() {
        super.spawnEffects();

        if (rand.nextBoolean() || !Config.enablePatreonEffects) return;

        int age = 30 + rand.nextInt(15);
        float scale = 0.1F + rand.nextFloat() * 0.1F;
        Vector3 at = new Vector3(this.pos);
        at.add(
            rand.nextFloat() * 0.08 * (rand.nextBoolean() ? 1 : -1),
            rand.nextFloat() * 0.08 * (rand.nextBoolean() ? 1 : -1),
            rand.nextFloat() * 0.08 * (rand.nextBoolean() ? 1 : -1));
        EntityFXFacingParticle particle = EffectHelper.genericFlareParticle(at);
        particle.scale(scale)
            .gravity(0.004)
            .enableAlphaFade(EntityComplexFX.AlphaFunction.FADE_OUT);
        particle.setColor(getColor());
        particle.setMaxAge(age);

        if (rand.nextBoolean()) {
            particle = EffectHelper.genericFlareParticle(at);
            particle.setColor(Color.WHITE)
                .enableAlphaFade(EntityComplexFX.AlphaFunction.FADE_OUT);
            particle.scale(scale * 0.3F)
                .gravity(0.004);
            particle.setMaxAge(age - 10);
        }
    }

    @SideOnly(Side.CLIENT)
    protected Color getColor() {
        return rand.nextInt(3) == 0 ? this.flareColor.color2 : this.flareColor.color1;
    }

    @SideOnly(Side.CLIENT)
    protected SpriteSheetResource getSprite() {
        return RowSpriteSheetResource.crop(this.flareColor.getTexture(), this.flareColor.spriteRowIndex());
    }

    @SideOnly(Side.CLIENT)
    public void tickInRenderDistance() {
        super.tickInRenderDistance();

        if (clientSprite != null) {
            EntityFXFacingSprite p = (EntityFXFacingSprite) clientSprite;
            if (p.isRemoved() && Config.enablePatreonEffects) {
                EffectHandler.getInstance()
                    .registerFX(p);
            }
        } else {
            EntityFXFacingSprite p = EntityFXFacingSprite
                .fromSpriteSheet(getSprite(), pos.getX(), pos.getY(), pos.getZ(), 0.35F, 2);
            p.setPositionUpdateFunction((fx, v, m) -> this.getPos());
            p.setRefreshFunc(() -> !removed && Config.enablePatreonEffects);
            EffectHandler.getInstance()
                .registerFX(p);
            this.clientSprite = p;
        }
    }

}
