/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.common.base.patreon.entity;

import java.awt.*;
import java.util.UUID;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import shordinger.astralsorcery.client.effect.EffectHandler;
import shordinger.astralsorcery.client.effect.EffectHelper;
import shordinger.astralsorcery.client.effect.EntityComplexFX;
import shordinger.astralsorcery.client.effect.fx.EntityFXFacingParticle;
import shordinger.astralsorcery.client.util.resource.AssetLoader;
import shordinger.astralsorcery.client.util.resource.TextureQuery;
import shordinger.astralsorcery.common.base.patreon.flare.PatreonPartialEntity;
import shordinger.astralsorcery.common.data.config.Config;
import shordinger.astralsorcery.common.util.data.Vector3;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: PartialEntityCrystal
 * Created by HellFirePvP
 * Date: 14.07.2018 / 19:25
 */
public class PartialEntityCrystal extends PatreonPartialEntity {

    private TextureQuery queryTexture = new TextureQuery(AssetLoader.TextureLocation.MODELS, "crystal_big_blue");
    private Color colorTheme = Color.WHITE;
    private Object clientEffect = null;

    public PartialEntityCrystal(UUID ownerUUID) {
        super(ownerUUID);
    }

    public PartialEntityCrystal setQueryTexture(TextureQuery queryTexture) {
        this.queryTexture = queryTexture;
        return this;
    }

    public PartialEntityCrystal setColorTheme(Color colorTheme) {
        this.colorTheme = colorTheme;
        return this;
    }

    @Override
    @SideOnly(Side.CLIENT)
    protected void spawnEffects() {
        super.spawnEffects();

        for (int i = 0; i < rand.nextInt(2) + 1; i++) {
            int age = 30 + rand.nextInt(15);
            float scale = 0.1F + rand.nextFloat() * 0.1F;
            Vector3 at = new Vector3(this.pos);
            at.add(
                rand.nextFloat() * 0.07 * (rand.nextBoolean() ? 1 : -1),
                rand.nextFloat() * 0.07 * (rand.nextBoolean() ? 1 : -1),
                rand.nextFloat() * 0.07 * (rand.nextBoolean() ? 1 : -1));
            at.addY(0.2F);
            Vector3 motion = Vector3.random()
                .multiply(0.01F);
            EntityFXFacingParticle particle = EffectHelper.genericFlareParticle(at);
            particle.scale(scale)
                .gravity(0.004)
                .enableAlphaFade(EntityComplexFX.AlphaFunction.FADE_OUT);
            particle.motion(motion.getX(), motion.getY(), motion.getZ());
            particle.setColor(rand.nextInt(3) == 0 ? this.colorTheme.brighter() : this.colorTheme);
            particle.setMaxAge(age);
        }
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void tickInRenderDistance() {
        super.tickInRenderDistance();

        if (clientEffect != null) {
            EffectFloatingCrystal crystal = (EffectFloatingCrystal) clientEffect;
            if (crystal.isRemoved() && Config.enablePatreonEffects) {
                EffectHandler.getInstance()
                    .registerFX(crystal);
            }
        } else {
            EffectFloatingCrystal crystal = new EffectFloatingCrystal();
            crystal.setPositionUpdateFunction((fx, v, m) -> this.getPos());
            crystal.setRefreshFunc(() -> !removed && Config.enablePatreonEffects);
            crystal.setTexture(queryTexture);
            crystal.setColorTheme(colorTheme);
            EffectHandler.getInstance()
                .registerFX(crystal);
            clientEffect = crystal;
        }
    }
}
