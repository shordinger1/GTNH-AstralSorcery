/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.client.effect.controller.orbital;

import java.awt.*;
import java.util.Random;

import shordinger.astralsorcery.client.effect.EffectHelper;
import shordinger.astralsorcery.client.effect.fx.EntityFXFacingParticle;
import shordinger.astralsorcery.common.util.data.Vector3;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: OrbitalEffectLucerna
 * Created by HellFirePvP
 * Date: 07.01.2017 / 19:26
 */
public class OrbitalEffectLucerna implements OrbitalEffectController.OrbitPersistence,
    OrbitalEffectController.OrbitPointEffect, OrbitalEffectController.OrbitTickModifier {

    private static final Random rand = new Random();

    private int count = 2 + rand.nextInt(2);

    @Override
    public boolean canPersist(OrbitalEffectController controller) {
        count--;
        return count > 0;
    }

    @Override
    public void doPointTickEffect(OrbitalEffectController ctrl, Vector3 pos) {
        if (rand.nextInt(2) == 0) {
            EntityFXFacingParticle p = EffectHelper.genericFlareParticle(pos.getX(), pos.getY(), pos.getZ());
            p.setMaxAge(45);
            p.offset(
                (rand.nextFloat() * 0.01F) * (rand.nextBoolean() ? 1 : -1),
                (rand.nextFloat() * 0.01F) * (rand.nextBoolean() ? 1 : -1),
                (rand.nextFloat() * 0.01F) * (rand.nextBoolean() ? 1 : -1));
            p.setColor(new Color(255, 255, 127));
            p.scale(0.25F)
                .gravity(0.008);
        }
        if (rand.nextInt(3) == 0) {
            EntityFXFacingParticle p = EffectHelper.genericFlareParticle(pos.getX(), pos.getY(), pos.getZ());
            p.motion(
                (rand.nextFloat() * 0.025F) * (rand.nextBoolean() ? 1 : -1),
                (rand.nextFloat() * 0.025F) * (rand.nextBoolean() ? 1 : -1),
                (rand.nextFloat() * 0.025F) * (rand.nextBoolean() ? 1 : -1));
            p.setMaxAge(35);
            p.scale(0.25F)
                .setColor(Color.WHITE);
        }
    }

    @Override
    public void onTick(OrbitalEffectController controller) {
        controller.getOffset()
            .add(0, 0.05, 0);
    }
}
