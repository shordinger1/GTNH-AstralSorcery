/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.client.gui.journal.bookmark;

import net.minecraft.client.gui.GuiScreen;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import shordinger.astralsorcery.client.util.resource.AbstractRenderableTexture;
import shordinger.astralsorcery.client.util.resource.AssetLibrary;
import shordinger.astralsorcery.client.util.resource.AssetLoader;
import shordinger.astralsorcery.common.util.Provider;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: BookmarkProvider
 * Created by HellFirePvP
 * Date: 26.11.2018 / 01:07
 */
@SideOnly(Side.CLIENT)
public class BookmarkProvider {

    private final Provider<GuiScreen> provider;
    private final int index;
    private final String unlocName;
    private final Provider<Boolean> canSeeTest;

    public BookmarkProvider(String unlocName, int bookmarkIndex, Provider<GuiScreen> guiProvider,
                            Provider<Boolean> canSeeTest) {
        this.unlocName = unlocName;
        this.index = bookmarkIndex;
        this.provider = guiProvider;
        this.canSeeTest = canSeeTest;
    }

    public GuiScreen getGuiScreen() {
        return provider.provide();
    }

    public boolean canSee() {
        return canSeeTest.provide();
    }

    public int getIndex() {
        return index;
    }

    public String getUnlocalizedName() {
        return unlocName;
    }

    public AbstractRenderableTexture getTextureBookmark() {
        return AssetLibrary.loadTexture(AssetLoader.TextureLocation.GUI, "guijbookmark");
    }

    public AbstractRenderableTexture getTextureBookmarkStretched() {
        return AssetLibrary.loadTexture(AssetLoader.TextureLocation.GUI, "guijbookmarkstretched");
    }

}
