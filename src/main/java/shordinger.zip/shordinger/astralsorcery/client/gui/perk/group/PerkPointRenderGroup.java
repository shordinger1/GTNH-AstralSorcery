/*******************************************************************************
 * HellFirePvP / Astral Sorcery 2019
 * Shordinger / GTNH AstralSorcery 2024
 * All rights reserved.
 *  Also Avaliable 1.7.10 source code in https://github.com/shordinger1/GTNH-AstralSorcery
 * For further details, see the License file there.
 ******************************************************************************/

package shordinger.astralsorcery.client.gui.perk.group;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import shordinger.astralsorcery.client.gui.perk.BatchPerkContext;
import shordinger.astralsorcery.client.gui.perk.PerkRenderGroup;
import shordinger.astralsorcery.client.util.SpriteLibrary;

/**
 * This class is part of the Astral Sorcery Mod
 * The complete source code for this mod can be found on github.
 * Class: PerkPointRenderGroup
 * Created by HellFirePvP
 * Date: 24.11.2018 / 11:52
 */
@SideOnly(Side.CLIENT)
public class PerkPointRenderGroup extends PerkRenderGroup {

    public static final PerkPointRenderGroup INSTANCE = new PerkPointRenderGroup();

    private PerkPointRenderGroup() {
        add(SpriteLibrary.spritePerkInactive, BatchPerkContext.PRIORITY_BACKGROUND + 1);
        add(SpriteLibrary.spritePerkActive, BatchPerkContext.PRIORITY_BACKGROUND + 2);
        add(SpriteLibrary.spritePerkActivateable, BatchPerkContext.PRIORITY_BACKGROUND + 3);
    }

}
